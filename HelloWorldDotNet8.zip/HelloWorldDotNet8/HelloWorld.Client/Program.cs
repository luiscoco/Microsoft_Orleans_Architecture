﻿using Hello.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Orleans;
using Orleans.Configuration;
using System;
using System.Threading.Tasks;
using HelloWorld.Grains;

namespace HelloWorld.Client
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var host = await StartClientWithRetries();
            var client = host.Services.GetRequiredService<IClusterClient>();
            await DoClientWork(client);
            Console.ReadKey();
        }

        static async Task<IHost> StartClientWithRetries()
        {
            var host = new HostBuilder()
            .UseOrleansClient((context, clientBuilder) =>
            {
                clientBuilder
                    .Configure<ClusterOptions>(options =>
                    {
                        options.ClusterId = "dev";
                        options.ServiceId = "HelloWorldApp";
                    })
                    .UseLocalhostClustering();
                // For production, replace the above line with the appropriate clustering provider,
                // for example, .UseAzureStorageClustering() with the necessary configuration.
            })
            .Build();

            await host.StartAsync();
            Console.WriteLine("Client successfully connected to silo host \n");
            return host;
        }

        static async Task DoClientWork(IClusterClient client)
        {
            var friend = client.GetGrain<Hello.Interfaces.IHello>(0);
            var response = await friend.SayHello("Good morning, my friend!");
            Console.WriteLine($"\n\n{response}\n\n");
        }
    }
}
